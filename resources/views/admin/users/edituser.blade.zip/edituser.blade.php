@extends('layouts.admin')
@section('breadcrum')
<div class="col-md-12 col-12 align-self-center">
    <h3 class="text-themecolor">Add User</h3>
    <ol class="breadcrumb" style="position: absolute;right: 0;top: 12px;">
        <li class="breadcrumb-item"><a href="{{url('designer/dashboard')}}">Dashboard</a></li>
    </ol>
</div>

@endsection

@section('section1')
<div class="card col-12">
<div class="card-body">
<a class="btn waves-effect waves-light btn-success pull-right" href="{{url('admin/cususers-view')}}">Back</a>
<div class="clearfix"></div>
  <div class="col-md-12">   	
		 <?php foreach($users as $user); ?>
		<form class="form form-horizontal" id="update-user">
		<input type="hidden" name="_token" value="{{ csrf_token() }}">
		<input type="hidden" name="id" value="{{$user->id}}">
		

			<hr>
			
<div id="error"></div><br>
					 
			<div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12 text-right" for="first-name">First Name<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" name="first-name" id="first-name" class="form-control" required value="{{$user->first_name}}" >
                        </div>
             </div>
			 
			 <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12 text-right" for="first-name">Last Name<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" name="last-name" id="last-name" class="form-control" required  value="{{$user->last_name}}">
                        </div>
             </div> 
			 
			 <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12 text-right" for="first-name">Email<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="email" name="email" id="email" class="form-control" required value="{{$user->email}}">
                        </div>
             </div> 
			 
			 <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12 text-right" for="first-name">Date Of Birth<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="date" name="dob" id="dob" class="form-control" required value="{{$user->dob}}">
                        </div>
             </div>
			 
			 
			 <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12 text-right" for="first-name">Gender<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <select class="form-control" name="gender" id="gender">
                         <option value="">Please select gender</option>
                           <option value="male" @if($user->gender=='male') selected @endif>Male</option>
							<option value="female" @if($user->gender=='female') selected @endif>Female</option>        
                          </select>
                        </div>
             </div>
			 

           
                    

</form>

<div class="clearfix"></div>
    
	 <div class="form-group row">
	    <div class="col-md-9 col-sm-9 col-xs-12">
		<button class="action submit btn btn-success pull-right" id="submit">Submit</button> 
		
		</div>
	</div>	
 </div>



</div>
</div>
@endsection

@section('section2')

@endsection

@section('footerscript')

<script type="text/javascript" src="{{asset('node_modules/sweetalert/dist/sweetalert.min.js')}}"></script>


<script type="text/javascript">
	$(function(){
		$(document).on('click','#submit',function(e){
			e.preventDefault();
			var Data = $("#update-user").serializeArray();
			
			

			$.ajax({
				url : '{{url("admin/cususers-update")}}',
				type : 'POST',
				data : Data,
				beforeSend : function(){
					
				},
				success : function(res){
					if(res == 0){
						$("#error").removeClass('alert alert-danger').addClass('alert alert-success').html('user created successfully.');
						setTimeout(function(){ window.location.assign('{{url("admin/cususers-view")}}')},2000);
					}else{
						$("#error").removeClass('alert alert-success').addClass('alert alert-danger').html('you have some errors while uploading a user,please check and try again.');
					}
				},
				complete : function(){}
			});
		});
	});
</script>
@endsection
