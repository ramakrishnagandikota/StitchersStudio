<ul id="menu-container">
	<li>
		<figure>
			<a href="{{ url('knitter/dashboard') }}"> <img class="dashboard-icons" src="{{ asset('resources/assets/files/assets/icon/custom-icon/home.png') }}"></a>
			<figcaption class="text-muted">Dashboard</figcaption>
		</figure>
	</li>
	<li>
		<figure>
			<a href="{{ url('knitter/project-library') }}"> <img class="dashboard-icons" src="{{ asset('resources/assets/files/assets/icon/custom-icon/Projects.png') }}"></a>
			<figcaption class="text-muted">Project Library</figcaption>
		</figure>
	</li>
	<li>
		<figure>
			<a href="{{ url('knitter/measurements') }}"> <img class="dashboard-icons" src="{{ asset('resources/assets/files/assets/icon/custom-icon/Measurement.png') }}"></a>
			<figcaption class="text-muted">Measurements</figcaption>
		</figure>
	</li>
	<li>
		<figure>
			<a href="{{ url('knitter/projects/custom/create') }}"> <img class="dashboard-icons" src="{{ asset('resources/assets/files/assets/icon/custom-icon/Pattern_Generator.png') }}" style="padding-top: 4px;"></a>
			<figcaption class="text-muted">Pattern Generator</figcaption>
		</figure>
	</li>
	<li>
		<figure>
			<a href="{{ url('connect') }}"> <img class="dashboard-icons" src="{{ asset('resources/assets/files/assets/icon/custom-icon/Timeline.png') }}"></a>
			<figcaption class="text-muted">Connect</figcaption>
		</figure>
	</li>
	<li>
		<figure>
			<a href="{{ url('shop-patterns') }}"> <img class="dashboard-icons" src="{{ asset('resources/assets/files/assets/icon/custom-icon/Shop-Design.png') }}"></a>
			<figcaption class="text-muted">Shop</figcaption>
		</figure>
	</li>
	@if(Auth::user()->hasRole('Designer'))
		<li>
			<figure class="m-b-5">
				<a href="{{ route('designer.main.my.patterns') }}">
					<img class="dashboard-icons" src="{{asset('resources/assets/files/assets/icon/custom-icon/pattern.png') }}" /></a>
				<figcaption class="text-muted">My Patterns</figcaption>
			</figure>
		</li>
	@endif
</ul>

