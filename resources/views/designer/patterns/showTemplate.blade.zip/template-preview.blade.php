<?php $inputs1 = array(); $inputs1A = array(); $inputs2 = array(); ?>
@if($measurements->count() > 0)
    @foreach($measurements as $meas)
        @php
            $measurementvalues = App\Models\Patterns\MeasurementValues::where('measurement_profile_id',$measurement_id)->where('measurement_variable_id',$meas->id)->first();
            $inp = strtoupper($meas->variable_name);
            $inputs1[] = str_replace(' ','_',$inp);

            $inp1 = strtolower($meas->variable_name);
            $inputs1A[] = str_replace(' ','_',$inp1);

            $inputs2[] = $measurementvalues->measurement_value;
        @endphp
    @endforeach
@endif
<?php
if(count($inputs1) == count($inputs2)) {
    $assArray = array();
    $assArray1 = array();
    for($i=0;$i<count($inputs1);$i++) {
        $assArray[$inputs1[$i]] = $inputs2[$i];
        $assArray1[$inputs1A[$i]] = $inputs2[$i];
    }
}

$inputs = array();
foreach ($inputs1 as $inp){
    $inputs[] = $inp;
}

$inparray = array('TITLE','UOM');
$arr2 = array_merge($inputs,$inparray);

$array = array('TITLE' => $mprofile->m_title,'UOM' => ($mprofile->uom == 'in') ? 'inches' : 'cm');
$arr1 = array_merge($assArray,$array);
?>

<div class="row">
    <div class="col-lg-12 col-md-12">
        <h5 class="p-10 text-center">
            {{ $template->template_name }}
        </h5>
    </div>
</div>
<div class="col-md-12">
    <div class="row theme-row m-b-10">
        <div class="card-header accordion active col-lg-12 col-sm-12" data-toggle="collapse" data-target="#PTsection1-preview">
            <h5 class="card-header-text">Project Information</h5>
            <i class="fa fa-caret-down pull-right micro-icons"></i>
        </div>
    </div>
    <div class="card-block collapse show" id="PTsection1-preview">
        <div class="col-lg-12">
            @php
            $tdescription = $template->description;
            for ($i=0;$i<count($arr1);$i++){
                $tdescription = str_replace('[['.$arr2[$i].']]',$arr1[$arr2[$i]],$tdescription);
            }
            @endphp
            {!! $tdescription !!}
        </div>
    </div>
</div>

<div class="clearfix"></div>
@if($template->getAllSections()->count() > 0)
    @foreach($template->getAllSections as $sections)
        <div class="col-md-12">
            <div class="row theme-row m-b-10">
                <div class="card-header accordion active col-lg-12 col-sm-12" data-toggle="collapse" data-target="#PTsection3{{$sections->id}}-preview">
                    <h5 class="card-header-text">{{ $sections->section_name }}</h5>
                    <i class="fa fa-caret-down pull-right micro-icons"></i>

                </div>
                <!--<a href="javascript:;" class="fa fa-comments pull-right sectionNotes" aria-hidden="true" onclick="opencommentbar({{$sections->id}})"></a> -->
            </div>

            <div class="card-block collapse show" id="PTsection3{{$sections->id}}-preview">

                @if($sections->snippets()->count() > 0)
                    @foreach($sections->snippets as $snippets)
                    <!-- snippet is empty -->
                        @if($snippets->is_empty == 1)
                            <div class="col-md-12">
                                @php
                                    $snippetsDescription = $snippets->snippet_description;
                                    for ($i=0;$i<count($arr1);$i++){
                                        $snippetsDescription = str_replace('[['.$arr2[$i].']]',$arr1[$arr2[$i]],$snippetsDescription);
                                    }
                                @endphp
                                {!! $snippetsDescription !!}
                            </div>
                        @endif
                    <!-- snippet is empty -->
                    <!-- Concatinate snippet -->
                        @if($snippets->is_concatinate == 1)
                            <div class="col-md-12">
                            @if($snippets->instructions()->count() > 0)
                                @foreach($snippets->instructions as $inst)
                                    @php
                                    $instruction = $inst->description;
                                    for ($i=0;$i<count($arr1);$i++){
                                        $instruction = str_replace('[['.$arr2[$i].']]',$arr1[$arr2[$i]],$instruction);
                                    }
                                    @endphp
                                    {!! $instruction !!}
                                @endforeach
                            @endif
                            </div>
                        @endif
                    <!-- Contatinate snippet -->

                    <!-- Yarn details -->
                        @if($snippets->is_yarn == 1)
                            @if($snippets->yarnDetails()->count() > 0)
                                <!--<h5 class="m-b-10">Suggested yarn</h5> -->
                                @foreach($snippets->yarnDetails as $yarnDetails)
                                    <div class="col-md-12">
                                        <a href="{{ $yarnDetails->yarn_content }}" style="color: #0d665c !important;text-decoration: underline;" class="YarnUrl" target="_blank">{{ ucfirst($yarnDetails->yarn_title) }}</a>
                                    </div>
                                @endforeach
                            @endif
                        @endif
                    <!-- yarn details -->

                    <!-- All functions start here -->

                        @if($snippets->function_id != 0)

                            @php
    $functions = App\Models\Patterns\Functions::where('id',$snippets->function_id)->first();
    $outputs = array('[[NO_OF_STITCHES_TO_CAST_ON]]','[[NO_OF_STITCHES_TO_CAST_ON_BACK]]','[[NO_OF_STITCHES_TO_CAST_ON_FRONT]]',"[[SIDE_MARKER]]",'[[SIDE_MARKER_FRONT]]',"[[SIDE_MARKER_1]]",'[[SIDE_MARKER_2]]','[[PRINCESS_DART_FRONT_2_PIECES]]','[[DECREASE_EVERY_N_ROWS_WAIST]]','[[NO_OF_TIMES_TO_DECREASE_WAIST]]','[[INCREASE_EVERY_N_ROWS_WAIST]]','[[NO_OF_TIMES_TO_INCREASE_TO_WAIST]]',"[[PRINCESS_DART]]",'[[SIDE_MARKER]]','[[PRINCESS_DART_FRONT_1]]','[[PRINCESS_DART_FRONT_2]]','[[PRINCESS_DART_BACK_1]]','[[PRINCESS_DART_BACK_2]]','[[INCREASE_EVERY_N_ROWS_BUST]]','[[NO_OF_TIMES_TO_INCREASE_BUST]]','[[DECREASE_EVERY_N_ROWS_BUST]]','[[NO_OF_TIMES_TO_DECREASE_BUST]]','[[SHOULDER_BIND_OFF_2]]','[[SHOULDER_BIND_OFF_3]]','[[SHOULDER_BIND_OFF_1]]','[[NO_OF_STITCHES_TO_CAST_ON_FOR_SLEEVE]]','[[NO_OF_ROWS_BETWEEN_INCREASES_AT FOREARM]]','[[NO_OF_TIMES_TO_INCREASE_AT_FOREARM]]','[[NO_OF_ROWS_BETWEEN_INCREASES_AT_UPPER_ARM]]','[[NO_OF_TIMES_TO_INCREASE_AT_UPPER_ARM]]','[[NO_OF_SLEEVE_STITCHES_AT_UPPER_ARM]]','[[NO_OF_STITCHES_FOR_FIRST_DECREASE_AT_ARMHOLE]]','[[NO_OF_STITCHES_FOR_SECOND_DECREASE_AT_ARMHOLE]]','[[NO_OF_STITCHES_FOR_THIRD_DECREASE_AT_ARMHOLE]]','[[NO_OF_STITCHES_FOR_4TH_DECREASE_AT_ARMHOLE]]','[[NO_OF_TIMES_TO_DECREASE_1_STITCH_AT_EACH_END]]','[[NO_OF_STITCHES_FOR_THIRD_DECREASE_AT_ARMHOLE]]','[[NO_OF_STITCHES_FOR_4TH_DECREASE_AT_ARMHOLE]]','[[NO_OF_TIMES_TO_DECREASE_1_STITCH_AT_EACH_END]]','[[NO_OF_ROWS_USED]]','[[NO_OF_ROWS_TO_KNIT_STRAIGHT]]','[[DEC_1_STITCH_EVERY_OTHER_ROW_X_TIMES]]','[[DEC_2_STITCH_EVERY_OTHER_ROW_X_TIMES]]','[[DEC_4_STITCH_EVERY_OTHER_ROW_X_TIMES]]','[[BO_REMAINING_1]]','[[BO_REMAINING_2]]','[[BO_REMAINING_3]]','[[TEXT_FOR_DECREASE_1_STITCH_AT_EACH_END]]','[[TEXT_FOR_NO_OF_STITCHES_FOR_THIRD_DECREASE_AT_ARMHOLE]]','[[TEXT_FOR_NO_OF_STITCHES_FOR_FOURTH_DECREASE_AT_ARMHOLE]]','[[LENGTH_OF_SLEEVE_CUFF]]','[[BIND_OFF_REMAINING]]','[[DEPTH_OF_NECKLINE]]','[[DEPTH_OF_NECKLINE_BACK]]','[[NO_OF_STITCHES_AT_FRONT_AFTER_ARM_SH]]','[[NO_OF_STITCHES_AT_LEFT_FRONT]]','[[NO_OF_STITCHES_AT_SHOULDER]]','[[NO_OF_STITCHES_AT_FRONT_AFTER_ARM_SH]]','[[TEXT_TO_DEC_2_STS]]','[[V_NECK_NO_TIMES_TO_DEC_1_ST]]','[[ARMHOLE_DEPTH_BEFORE_SHOULDER_BIND_OFF]]','[[NO_OF_STITCHES_AT_BACK_AFTER_ARM_SH]]','[[NO_OF_STITCHES_AT_LEFT_BACK]]','[[CENTER_BACK_NECK_BINDOFF]]','[[NO_OF_LEFT_SHOULDER_STS_SCOOP]]','[[NO_OF_BACK_NECK_STS]]');

    $outputs1 = array('NO_OF_STITCHES_TO_CAST_ON','NO_OF_STITCHES_TO_CAST_ON_BACK','NO_OF_STITCHES_TO_CAST_ON_FRONT',"SIDE_MARKER",'SIDE_MARKER_FRONT',"SIDE_MARKER_1",'SIDE_MARKER_2','PRINCESS_DART_FRONT_2_PIECES','DECREASE_EVERY_N_ROWS_WAIST','NO_OF_TIMES_TO_DECREASE_WAIST','INCREASE_EVERY_N_ROWS_WAIST','NO_OF_TIMES_TO_INCREASE_TO_WAIST',"PRINCESS_DART",'SIDE_MARKER','PRINCESS_DART_FRONT_1','PRINCESS_DART_FRONT_2','PRINCESS_DART_BACK_1','PRINCESS_DART_BACK_2','INCREASE_EVERY_N_ROWS_BUST','NO_OF_TIMES_TO_INCREASE_BUST','DECREASE_EVERY_N_ROWS_BUST','NO_OF_TIMES_TO_DECREASE_BUST','SHOULDER_BIND_OFF_1','SHOULDER_BIND_OFF_2','SHOULDER_BIND_OFF_3','NO_OF_STITCHES_TO_CAST_ON_FOR_SLEEVE','NO_OF_ROWS_BETWEEN_INCREASES_AT FOREARM','NO_OF_TIMES_TO_INCREASE_AT_FOREARM','NO_OF_ROWS_BETWEEN_INCREASES_AT_UPPER_ARM','NO_OF_TIMES_TO_INCREASE_AT_UPPER_ARM','NO_OF_SLEEVE_STITCHES_AT_UPPER_ARM','NO_OF_STITCHES_FOR_FIRST_DECREASE_AT_ARMHOLE','NO_OF_STITCHES_FOR_SECOND_DECREASE_AT_ARMHOLE','NO_OF_STITCHES_FOR_THIRD_DECREASE_AT_ARMHOLE','NO_OF_STITCHES_FOR_4TH_DECREASE_AT_ARMHOLE','NO_OF_TIMES_TO_DECREASE_1_STITCH_AT_EACH_END','NO_OF_STITCHES_FOR_THIRD_DECREASE_AT_ARMHOLE','NO_OF_STITCHES_FOR_4TH_DECREASE_AT_ARMHOLE','NO_OF_TIMES_TO_DECREASE_1_STITCH_AT_EACH_END','NO_OF_ROWS_USED','NO_OF_ROWS_TO_KNIT_STRAIGHT','DEC_1_STITCH_EVERY_OTHER_ROW_X_TIMES','DEC_2_STITCH_EVERY_OTHER_ROW_X_TIMES','DEC_4_STITCH_EVERY_OTHER_ROW_X_TIMES','BO_REMAINING_1','BO_REMAINING_2','BO_REMAINING_3','TEXT_FOR_DECREASE_1_STITCH_AT_EACH_END','TEXT_FOR_NO_OF_STITCHES_FOR_THIRD_DECREASE_AT_ARMHOLE','TEXT_FOR_NO_OF_STITCHES_FOR_FOURTH_DECREASE_AT_ARMHOLE','LENGTH_OF_SLEEVE_CUFF','BIND_OFF_REMAINING','DEPTH_OF_NECKLINE','DEPTH_OF_NECKLINE_BACK','NO_OF_STITCHES_AT_FRONT_AFTER_ARM_SH','NO_OF_STITCHES_AT_LEFT_FRONT','NO_OF_STITCHES_AT_SHOULDER','NO_OF_STITCHES_AT_FRONT_AFTER_ARM_SH','TEXT_TO_DEC_2_STS','V_NECK_NO_TIMES_TO_DEC_1_ST','ARMHOLE_DEPTH_BEFORE_SHOULDER_BIND_OFF','NO_OF_STITCHES_AT_BACK_AFTER_ARM_SH','NO_OF_STITCHES_AT_LEFT_BACK','CENTER_BACK_NECK_BINDOFF','NO_OF_LEFT_SHOULDER_STS_SCOOP','NO_OF_BACK_NECK_STS');

        if($snippets->factor_value_cm == 0){
            $factor_value = $snippets->factor_value_in;
        }else if($snippets->factor_value_in == 0){
            $factor_value = $snippets->factor_value_cm;
        }else{
            $factor_value = 0;
        }

        if($functions->prgm_name == 'cast_on_1'){
            $functionName = cast_on_1($assArray1, $factor_value, $snippets->modifier_value);
        }else if($functions->prgm_name == 'cast_on_2_front'){
            $functionName = cast_on_2_front($assArray1, $factor_value, $snippets->modifier_value);
        }else if($functions->prgm_name == 'cast_on_2_back'){
            $functionName = cast_on_2_back($assArray1, $factor_value, $snippets->modifier_value);
        }else if($functions->prgm_name == 'cast_on_3_front'){
            $functionName = cast_on_3_front($assArray1, $factor_value, $snippets->modifier_value);
        }else if($functions->prgm_name == 'cast_on_3_back'){
            $functionName = cast_on_3_back($assArray1, $factor_value, $snippets->modifier_value);
        }else if($functions->prgm_name == 'place_markers_side_markers_1'){
            $hierarchy = App\Models\Patterns\FunctionsHierarchy::where('child_functions_id',$functions->id)->get();
            if($hierarchy->count() > 0){
                foreach($hierarchy as $hi){
                    $params = App\Models\Patterns\Snippet::where('function_id',$hi->parent_functions_id)->first();
                    if($mprofile->uom == 'cm'){
                        $factor_value1 = $params->factor_value_cm;
                    }else if($mprofile->uom == 'in'){
                        $factor_value1 = $params->factor_value_in;
                    }else{
                        $factor_value1 = 0;
                    }
                    $functionName = place_markers_side_markers_1($assArray1, $factor_value1, $params->modifier_value);
                }
            }
        }else if($functions->prgm_name == 'place_markers_side_markers_2'){
            $hierarchy = App\Models\Patterns\FunctionsHierarchy::where('child_functions_id',$functions->id)->get();
            if($hierarchy->count() > 0){
                foreach($hierarchy as $hi){
                    $params = App\Models\Patterns\Snippet::where('function_id',$hi->parent_functions_id)->first();
                    if($mprofile->uom == 'cm'){
                        $factor_value1 = $params->factor_value_cm;
                    }else if($mprofile->uom == 'in'){
                        $factor_value1 = $params->factor_value_in;
                    }else{
                        $factor_value1 = 0;
                    }
                $functionName = place_markers_side_markers_2($assArray1, $factor_value1, $params->modifier_value);
                }
            }
        }else if($functions->prgm_name == 'place_markers_princes_dart_1'){
            $hierarchy = App\Models\Patterns\FunctionsHierarchy::where('child_functions_id',$functions->id)->get();
            if($hierarchy->count() > 0){
                foreach($hierarchy as $hi){
                    $params = App\Models\Patterns\Snippet::where('function_id',$hi->parent_functions_id)->first();
                    if($mprofile->uom == 'cm'){
                        $factor_value1 = $params->factor_value_cm;
                    }else if($mprofile->uom == 'in'){
                        $factor_value1 = $params->factor_value_in;
                    }else{
                        $factor_value1 = 0;
                    }
                   $functionName = place_markers_princes_dart_1($assArray1, $factor_value1, $params->modifier_value);
                }
            }

        }else if($functions->prgm_name == 'place_markers_princes_dart_2_front'){
            $hierarchy = App\Models\Patterns\FunctionsHierarchy::where('child_functions_id',$functions->id)->get();
            if($hierarchy->count() > 0){
                foreach($hierarchy as $hi){
                    $params = App\Models\Patterns\Snippet::where('function_id',$hi->parent_functions_id)->first();
                    if($mprofile->uom == 'cm'){
                        $factor_value1 = $params->factor_value_cm;
                    }else if($mprofile->uom == 'in'){
                        $factor_value1 = $params->factor_value_in;
                    }else{
                        $factor_value1 = 0;
                    }
                   $functionName = place_markers_princes_dart_2_front($assArray1, $factor_value1, $params->modifier_value);
                }
            }
            //$functionName = place_markers_princes_dart_2_front($assArray1, $factor_value, $snippets->modifier_value);
        }else if($functions->prgm_name == 'place_markers_princes_dart_2_back'){
            $hierarchy = App\Models\Patterns\FunctionsHierarchy::where('child_functions_id',$functions->id)->get();
            if($hierarchy->count() > 0){
                foreach($hierarchy as $hi){
                    $params = App\Models\Patterns\Snippet::where('function_id',$hi->parent_functions_id)->first();
                    if($mprofile->uom == 'cm'){
                        $factor_value1 = $params->factor_value_cm;
                    }else if($mprofile->uom == 'in'){
                        $factor_value1 = $params->factor_value_in;
                    }else{
                        $factor_value1 = 0;
                    }
                   $functionName = place_markers_princes_dart_2_back($assArray1, $factor_value1, $params->modifier_value);
                }
            }
            //$functionName = place_markers_princes_dart_2_back($assArray1, $factor_value, $snippets->modifier_value);
        }else if($functions->prgm_name == 'place_markers_princes_dart_3'){
            $hierarchy = App\Models\Patterns\FunctionsHierarchy::where('child_functions_id',$functions->id)->get();
            if($hierarchy->count() > 0){
                foreach($hierarchy as $hi){
                    $params = App\Models\Patterns\Snippet::where('function_id',$hi->parent_functions_id)->first();
                    if($mprofile->uom == 'cm'){
                        $factor_value1 = $params->factor_value_cm;
                    }else if($mprofile->uom == 'in'){
                        $factor_value1 = $params->factor_value_in;
                    }else{
                        $factor_value1 = 0;
                    }
                   $functionName = place_markers_princes_dart_3($assArray1, $factor_value1, $params->modifier_value);
                }
            }
            //$functionName = place_markers_princes_dart_3($assArray1, $factor_value, $snippets->modifier_value);
        }else if($functions->prgm_name == 'place_markers_princes_dart_4_front'){
            $hierarchy = App\Models\Patterns\FunctionsHierarchy::where('child_functions_id',$functions->id)->get();
            if($hierarchy->count() > 0){
                foreach($hierarchy as $hi){
                    $params = App\Models\Patterns\Snippet::where('function_id',$hi->parent_functions_id)->first();
                    if($mprofile->uom == 'cm'){
                        $factor_value1 = $params->factor_value_cm;
                    }else if($mprofile->uom == 'in'){
                        $factor_value1 = $params->factor_value_in;
                    }else{
                        $factor_value1 = 0;
                    }
                   $functionName = place_markers_princes_dart_4_front($assArray1, $factor_value1, $params->modifier_value);
                }
            }
            //$functionName = place_markers_princes_dart_4_front($assArray1, $factor_value, $snippets->modifier_value);
        }else if($functions->prgm_name == 'place_markers_princes_dart_4_back'){
            $hierarchy = App\Models\Patterns\FunctionsHierarchy::where('child_functions_id',$functions->id)->get();
            if($hierarchy->count() > 0){
                foreach($hierarchy as $hi){
                    $params = App\Models\Patterns\Snippet::where('function_id',$hi->parent_functions_id)->first();
                    if($mprofile->uom == 'cm'){
                        $factor_value1 = $params->factor_value_cm;
                    }else if($mprofile->uom == 'in'){
                        $factor_value1 = $params->factor_value_in;
                    }else{
                        $factor_value1 = 0;
                    }
                   $functionName = place_markers_princes_dart_4_back($assArray1, $factor_value1, $params->modifier_value);
                }
            }
            //$functionName = place_markers_princes_dart_4_back($assArray1, $factor_value, $snippets->modifier_value);
        }else if($functions->prgm_name == 'decrease_to_waist_1'){
            $functionName = decrease_to_waist_1($assArray1, $factor_value);
        }else if($functions->prgm_name == 'decrease_to_waist_2_front'){
            $functionName = decrease_to_waist_2_front($assArray1, $factor_value);
        }else if($functions->prgm_name == 'decrease_to_waist_2_back'){
            $functionName = decrease_to_waist_2_back($assArray1, $factor_value);
        }else if($functions->prgm_name == 'decrease_to_waist_3'){
            $functionName = decrease_to_waist_3($assArray1, $factor_value);
        }else if($functions->prgm_name == 'decrease_to_waist_4_front'){
            $functionName = decrease_to_waist_4_front($assArray1, $factor_value);
        }else if($functions->prgm_name == 'decrease_to_waist_4_back'){
            $functionName = decrease_to_waist_4_back($assArray1, $factor_value);
        }else if($functions->prgm_name == 'increase_to_bust_1_front'){
            $functionName = increase_to_bust_1_front($assArray1);
        }else if($functions->prgm_name == 'increase_to_back_1_back'){
            $functionName = increase_to_back_1_back($assArray1);
        }else if($functions->prgm_name == 'increase_to_bust_2_front'){
            $functionName = increase_to_bust_2_front($assArray1);
        }else if($functions->prgm_name == 'increase_to_back_2_back'){
            $functionName = increase_to_back_2_back($assArray1);
        }else if($functions->prgm_name == 'increase_to_bust_3_front'){
            $functionName = increase_to_bust_3_front($assArray1);
        }else if($functions->prgm_name == 'increase_to_back_3_back'){
            $functionName = increase_to_back_3_back($assArray1);
        }else if($functions->prgm_name == 'increase_to_bust_4_left_front'){
            $functionName = increase_to_bust_4_left_front($assArray1);
        }else if($functions->prgm_name == 'increase_to_bust_4_right_front'){
            $functionName = increase_to_bust_4_right_front($assArray1);
        }else if($functions->prgm_name == 'increase_to_back_4_back'){
            $functionName = increase_to_back_4_back($assArray1);
        }else if($functions->prgm_name == 'shoulder_shaping_1'){ // shoulder bind off;
            $functionName = shoulder_shaping_1($assArray1);
        }else if($functions->prgm_name == 'shoulder_shaping_2'){ // shoulder bind off;
            $functionName = shoulder_shaping_2($assArray1);
        }else if($functions->prgm_name == 'shoulder_shaping_3'){ // shoulder bind off;
            $functionName = shoulder_shaping_3($assArray1);
        }else if($functions->prgm_name == 'shoulder_shaping_4'){ // shoulder bind off;
            $functionName = shoulder_shaping_4($assArray1);
        }else if($functions->prgm_name == 'sleeve_cast_on_1'){ // Sleeve cast on;
            $functionName = sleeve_cast_on_1($assArray1,$factor_value);
        }else if($functions->prgm_name == 'sleeve_cast_on_2'){ // Sleeve cast on;
            $functionName = sleeve_cast_on_2($assArray1,$factor_value);
        }else if($functions->prgm_name == 'sleeve_cast_on_3'){ // Sleeve cast on;
            $functionName = sleeve_cast_on_3($assArray1,$factor_value);
        }else if($functions->prgm_name == 'sleeve_cast_on_4'){ // Sleeve cast on;
            $functionName = sleeve_cast_on_4($assArray1,$factor_value);
        }else if($functions->prgm_name == 'increase_to_forearm_1'){ // Increase to forearm;
            $functionName = increase_to_forearm_1($assArray1,$factor_value);
        }else if($functions->prgm_name == 'increase_to_forearm_2'){ // Increase to forearm;
            $functionName = increase_to_forearm_2($assArray1,$factor_value);
        }else if($functions->prgm_name == 'increase_to_forearm_3'){ // Increase to forearm;
            $functionName = increase_to_forearm_3($assArray1,$factor_value);
        }else if($functions->prgm_name == 'increase_to_forearm_4'){ // Increase to forearm;
            $functionName = increase_to_forearm_4($assArray1,$factor_value);
        }else if($functions->prgm_name == 'increase_to_upperarm_1'){ // Increase to upperarm;
            $functionName = increase_to_upperarm_1($assArray1);
        }else if($functions->prgm_name == 'increase_to_upperarm_2'){ // Increase to upperarm;
            $functionName = increase_to_upperarm_2($assArray1);
        }else if($functions->prgm_name == 'increase_to_upperarm_3'){ // Increase to upperarm;
            $functionName = increase_to_upperarm_3($assArray1);
        }else if($functions->prgm_name == 'increase_to_upperarm_4'){ // Increase to upperarm;
            $functionName = increase_to_upperarm_4($assArray1);
        }else if($functions->prgm_name == 'armhole_shaping_1'){ // Increase to upperarm;
            $functionName = armhole_shaping_1($assArray1);
        }else if($functions->prgm_name == 'armhole_shaping_2'){ // Increase to upperarm;
            $functionName = armhole_shaping_2($assArray1);
        }else if($functions->prgm_name == 'armhole_shaping_3_front'){ // Increase to upperarm;
            $functionName = armhole_shaping_3_front($assArray1);
        }else if($functions->prgm_name == 'armhole_shaping_3_back'){ // Increase to upperarm;
            $functionName = armhole_shaping_3_back($assArray1);
        }else if($functions->prgm_name == 'armhole_shaping_4_front'){ // Increase to upperarm;
            $functionName = armhole_shaping_4_front($assArray1);
        }else if($functions->prgm_name == 'armhole_shaping_4_back'){ // Increase to upperarm;
            $functionName = armhole_shaping_4_back($assArray1);
        }else if($functions->prgm_name == 'sleeve_cap_shaping_1'){ // Increase to upperarm;
            $functionName = sleeve_cap_shaping_1($assArray1);
        }else if($functions->prgm_name == 'sleeve_cap_shaping_2'){ // Increase to upperarm;
            $functionName = sleeve_cap_shaping_2($assArray1);
        }else if($functions->prgm_name == 'sleeve_cap_shaping_3'){ // Increase to upperarm;
            $functionName = sleeve_cap_shaping_3($assArray1);
        }else if($functions->prgm_name == 'sleeve_cap_shaping_4'){ // Increase to upperarm;
            $functionName = sleeve_cap_shaping_4($assArray1);
        }else if($functions->prgm_name == 'depth_of_neckline_1'){
            $functionName = depth_of_neckline_1($assArray1,$factor_value);
        }else if($functions->prgm_name == 'depth_of_neckline_2'){
            $functionName = depth_of_neckline_2($assArray1,$factor_value);
        }else if($functions->prgm_name == 'depth_of_neckline_3'){
            $functionName = depth_of_neckline_3($assArray1,$factor_value);
        }else if($functions->prgm_name == 'depth_of_neckline_4'){
            $functionName = depth_of_neckline_4($assArray1,$factor_value);
        }else if($functions->prgm_name == 'depth_of_neckline_back_1'){
            $functionName = depth_of_neckline_back_1($assArray1,$factor_value);
        }else if($functions->prgm_name == 'depth_of_neckline_back_2'){
            $functionName = depth_of_neckline_back_2($assArray1,$factor_value);
        }else if($functions->prgm_name == 'depth_of_neckline_back_3'){
            $functionName = depth_of_neckline_back_3($assArray1,$factor_value);
        }else if($functions->prgm_name == 'depth_of_neckline_back_4'){
            $functionName = depth_of_neckline_back_4($assArray1,$factor_value);
        }else if($functions->prgm_name == 'left_right_front_to_shape_neckline_1'){
            $functionName = left_right_front_to_shape_neckline_1($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'left_right_front_to_shape_neckline_2'){
            $functionName = left_right_front_to_shape_neckline_2($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'left_right_front_to_shape_neckline_3'){
            $functionName = left_right_front_to_shape_neckline_3($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'left_right_front_to_shape_neckline_4'){
            $functionName = left_right_front_to_shape_neckline_4($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'shape_neckline_v_neck_1'){
            $functionName = shape_neckline_v_neck_1($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'shape_neckline_v_neck_2'){
            $functionName = shape_neckline_v_neck_2($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'shape_neckline_v_neck_3'){
            $functionName = shape_neckline_v_neck_3($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'shape_neckline_v_neck_4'){
            $functionName = shape_neckline_v_neck_4($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'left_right_back_to_shape_neckline_1'){
            $functionName = left_right_back_to_shape_neckline_1($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'left_right_back_to_shape_neckline_2'){
            $functionName = left_right_back_to_shape_neckline_2($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'left_right_back_to_shape_neckline_3'){
            $functionName = left_right_back_to_shape_neckline_3($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'left_right_back_to_shape_neckline_4'){
            $functionName = left_right_back_to_shape_neckline_4($assArray1,$mprofile,$snippets);
        }else if($functions->prgm_name == 'bind_off_scoop_neck_front_1'){
            $functionName = bind_off_scoop_neck_front_1($assArray1,$mprofile,$snippets,$factor_value);
        }else if($functions->prgm_name == 'bind_off_scoop_neck_front_2'){
            $functionName = bind_off_scoop_neck_front_2($assArray1,$mprofile,$snippets,$factor_value);
        }else if($functions->prgm_name == 'bind_off_scoop_neck_front_3'){
            $functionName = bind_off_scoop_neck_front_3($assArray1,$mprofile,$snippets,$factor_value);
        }else if($functions->prgm_name == 'bind_off_scoop_neck_front_4'){
            $functionName = bind_off_scoop_neck_front_4($assArray1,$mprofile,$snippets,$factor_value);
        }

        $function = unserialize($functionName);

        //print_r($function);
        //$outputVariables = $functions->outputVariables()->select('variable_name')->get();
        //$condition = App\Models\Patterns\ConditionalStatement::where('id',$function['condition_id'])->first();
        //$baseInstruction = $condition->base_instructions;
        $sinstructions = DB::table('p_snippet_instructions')->where('snippets_id',$snippets->id)->where('conditional_statements_id',$function['condition_id'])->get();
        @endphp

                            @if($sinstructions->count() > 0)
                                <?php $pi=1; ?>
                                @foreach($sinstructions as $inst)
                                    @php
                                        $instructions = App\Models\Patterns\Instructions::where('id',$inst->instructions_id)->get();
                                    @endphp
                                    @foreach($instructions as $ins)
                                        <?php $baseInstruction = $ins->description; ?>
                                        <!-- output variables -->
                                            @if($functions->outputVariables()->count() > 0)
                                                @foreach($functions->outputVariables as $outVars)
                                                    @php
                                                        $outputVar = '[['.$outVars->variable_name.']]';
                                                        $out = $outVars->variable_name;
                                                        $functionOut = isset($function[$out]) ? $function[$out] : 0;
                                                        //echo $function[$out];
                                                        $baseInstruction = str_replace($outputVar,$functionOut, $baseInstruction);
                                                    @endphp
                                                @endforeach
                                            @endif
                                        <!-- output variables -->

                                    @endforeach
                                    <?php $pi++; ?>
                                @endforeach
                            @endif

                            @php
                                for ($i=0;$i<count($arr1);$i++){
                                    $baseInstruction = str_replace('[['.$arr2[$i].']]',$arr1[$arr2[$i]],$baseInstruction);
                                }
                            @endphp

                            <div class="col-md-12">{!! $baseInstruction !!}</div>


                        @endif
                    <!-- All functions end here -->
                    @endforeach
                @endif
            </div>
        </div>
    @endforeach
@endif
