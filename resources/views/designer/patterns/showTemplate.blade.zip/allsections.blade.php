
@if($allsections->count() > 0)
    @php $sec = 1; @endphp
    @foreach($allsections as $allsec)

        <div class="row theme-row m-b-10 section{{$allsec->id}}" >
            <div class="card-header accordion col-lg-12 col-sm-12" data-toggle="collapse" data-target="#PTsection4{{ $allsec->id }}">
                <h5 class="card-header-text username" data-type="text" data-pk="{{ $allsec->id }}_{{$pattern_template_id}}" >{{ $allsec->section_name }}</h5>
                @if($sec == $allsections->count())
                    <a href="javascript:;" data-sections-id="{{ $allsec->id }}" class="pull-right fa fa-trash deleteSection" data-id="{{ $allsec->id }}" data-server="false" ></a>
                @endif
                <i class="icon fa fa-caret-down pull-right micro-icons"></i>
            </div>
        </div>


        <div class="card-block collapse section{{ $allsec->id }}" id="PTsection4{{ $allsec->id }}">
            <!--Starting snippets Box-->
            @if($allsec->snippets()->count() > 0)
                <?php $se = 1; ?>
                @foreach($allsec->snippets as $snip)
                    <div class="allsnippets" id="snippet{{$se}}">
                        <form class="form" id="sectionForm{{$allsec->id}}{{$se}}" method="POST" action="{{ route("update.snippet.data")}}">
                            <input type="hidden" name="snippet_id" value="{{$snip->id}}">
                            <input type="hidden" name="snippet_name" value="{{$snip->snippet_name}}">
                            <input type="hidden" name="section_id" value="{{ $allsec->id }}">
							<input type="hidden" name="pattern_template_id" value="{{ $pattern_template_id }}">
                            <div class="form-group row m-b-zero p-10 bordered-box snippets" id="add-function-box">

                                <div class="col-lg-8 row-bg">
                                    <h6 class="m-b-5 m-t-5">{{ $snip->snippet_name }}</h6>
                                </div>
                                <div class="col-lg-4 row-bg text-right">
                                    @if($se == $allsec->snippets()->count())
                                        <a href="javascript:;" class="deleteSnippet fa fa-trash pull-right" data-id="{{ $snip->id }}" ></a>
                                    @endif
                                </div>

                                <!-- empty snippet starts here -->
                                @if($snip->is_empty == 1)
                                    <div class="col-lg-12">
                                        <input type="hidden" name="is_empty" value="{{ $snip->is_empty }}">
                                        <textarea class="hint2mention summernoteDescription m-b-10" name="snippet_description">{!! $snip->snippet_description !!}</textarea>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <button type="button" class="btn theme-btn btn-sm pull-right m-t-10 updateSnippet" data-snippet-id="{{ $se }}" data-id="sectionForm{{$allsec->id}}{{$se}}">Save</button>
                                            </div>
                                        </div>
                                    </div>

                                @endif



                                @if($snip->is_yarn == 1)

                                    <div class="col-lg-12">

                                        <div class="row">
                                            <h5 class="theme-light-row col-md-12">Yarn details</h5>
                                            <a href="javascript:;" id="add-yarnDetail" data-toggle="tooltip" title="Add new yarn url" data-id="{{$snip->id}}" class="add-yarn-detail add-yarnDetail"><i class="fa fa-plus-circle fa-2x"></i></a>
                                        </div>

                                        <input type="hidden" name="is_yarn" value="{{ $snip->is_yarn }}">
                                        <div class="row m-t-10" id="addYarnData{{$snip->id}}">
                                            @if($snip->yarnDetails()->count() > 0)
                                                <?php $y = 0; ?>
                                                @foreach($snip->yarnDetails as $yd)
                                                    <div class="col-md-6 allYd m-b-10" id="yd{{$yd->id}}">
                                                        <input type="hidden" name="yarn_detail_id[]" value="{{ $yd->id }}">
                                                        <input type="text" class="form-control" name="yarn_title[]" value="{{ $yd->yarn_title }}"><br>
                                                        <textarea name="yarn_details[]" class="form-control" required="required" placeholder="Enter yarn url">{!! $yd->yarn_content !!}</textarea>
                                                        <a href="javascript:;" data-server="true" class="delete-yarn-details" data-id="{{$yd->id}}"><i class="fa fa-trash"></i></a>
                                                    </div>
                                                    <?php $y++; ?>
                                                @endforeach
                                            @endif
                                        </div>


                                        <div class="row">
                                            <div class="col-lg-12">
                                                <button type="button" class="btn theme-btn btn-sm pull-right m-t-10 updateSnippet" data-snippet-id="{{ $se }}" data-id="sectionForm{{$allsec->id}}{{$se}}">Save</button>
                                            </div>
                                        </div>
                                    </div>
                                @endif


                            <!-- empty snippet ends here -->

                                <!--
                   /******************** Concatinate snippet removed from here ***************************/
                                     -->

                                <!-- formulas start here -->
                                @if($snip->function_id != 0)
                                    @php
                                        $function = App\Models\Patterns\Functions::where('id',$snip->function_id)->first();
                                    @endphp


                                    <div class="col-lg-12">
                                        <div class="row">
                                            @if($designType->functions()->count() > 0)
                                                <div class="col-md-3 m-b-20">
                                                    <select disabled class="form-control fill select-formula"  data-section-id="{{$se}}" data-id="{{$allsec->id}}{{$se}}" data-count="{{$se}}">
                                                        <option value="">Select a snippet</option>
                                                        <optgroup label="Select Snippet">
                                                            <option value="empty">Empty Snippet</option>
                                                            <!--<option value="concatinate">Concatinate Snippet</option>-->
                                                            <option value="yarndetails">Yarn Details Snippet</option>
                                                        </optgroup>
                                                        <optgroup label="Select Formula">

                                                            @foreach($designType->functions as $dtf)
                                                                <option value="{{ $dtf->id }}" @if($function->id == $dtf->id) selected @endif >{{ ucfirst($dtf->function_name) }}</option>
                                                            @endforeach
                                                        </optgroup>
                                                    </select>
                                                    <input type="hidden" name="function_name" value="{{ $function->id }}">
                                                    <span class="function_name text-danger"></span>
                                                </div>
                                        @endif

                                        <!--End snippets Box-->
                                        </div>
                                    </div>



                                    <div class="col-md-12" id="functionData{{$allsec->id}}{{$se}}">
                                        <div class="row">

                                            <div class="col-lg-12 snippet-accordion factor_column">
                                                <div class="row theme-row m-b-10">
                                                    <div class="card-header accordion p-1 col-lg-12 col-sm-12" data-toggle="collapse" data-target="#child-sampleInstruction{{ $allsec->id }}{{$se}}">
                                                        <h5 class="card-header-text">Sample Instruction:</h5><i class="icon fa fa-caret-down pull-right micro-icons"></i> </div>
                                                </div>
                                                <div class="card-block collapse" id="child-sampleInstruction{{ $allsec->id }}{{$se}}">
                                                    <p>CO [[NO_OF_STITCHES_TO_CAST_ON]] stitches.</p>
                                                    <h5>Sample Output : </h5>
                                                    <p class="m-t-5">CO 256 stitches.</p>
                                                </div>
                                            </div>

                                            <input type="hidden" id="section_id" name="section_id" value="{{ $allsec->id }}{{$se}}">
                                            @if($function->inputVariables()->count() > 0)

                                                <div class="col-lg-6 snippet-accordion">
                                                    <div class="row theme-row m-b-10">
                                                        <div class="card-header accordion p-1 col-lg-12 col-sm-12" data-toggle="collapse" data-target="#child-accord1Inputs{{ $allsec->id }}{{$se}}">
                                                            <h5 class="card-header-text">Inputs:</h5><i class="icon fa fa-caret-down pull-right micro-icons"></i> </div>
                                                    </div>
                                                    <div class="card-block collapse" id="child-accord1Inputs{{ $allsec->id }}{{$se}}">
                                                        @foreach($function->inputVariables as $inp)
                                                            <li>{{ ucfirst($inp->variable_name) }}</li>
                                                        @endforeach
                                                    </div>
                                                </div>

                                            @endif

                                            @if($function->outputVariables()->count() > 0)

                                                <div class="col-lg-6 snippet-accordion factor_column">
                                                    <div class="row theme-row m-b-10">
                                                        <div class="card-header accordion p-1 col-lg-12 col-sm-12" data-toggle="collapse" data-target="#child-accord1output{{ $allsec->id }}{{$se}}">
                                                            <h5 class="card-header-text">Output variables:</h5><i class="icon fa fa-caret-down pull-right micro-icons"></i> </div>
                                                    </div>
                                                    <div class="card-block collapse" id="child-accord1output{{ $allsec->id }}{{$se}}">
                                                        <ul class="list-unstyled" id="output-variables">
                                                            @foreach($function->outputVariables as $out)
                                                                <li>{{ $out->variable_name }}</li>
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            @endif

                                            @if($function->factor_id_in != 0)
                                                @php
                                                    $factor = App\Models\Patterns\Factor::where('id',$function->factor_id_in)->first();
                                                @endphp

                                                <div class="col-lg-6 snippet-accordion factor_column">
                                                    <div class="row theme-row m-b-10">
                                                        <div class="card-header accordion p-1 col-lg-12 col-sm-12" data-toggle="collapse" data-target="#child-accord1factor_column{{ $allsec->id }}{{$se}}">
                                                            <h5 class="card-header-text">{{ $factor->factor_name }}:</h5><i class="icon fa fa-caret-down pull-right micro-icons"></i> </div>
                                                    </div>
                                                    <div class="card-block collapse" id="child-accord1factor_column{{ $allsec->id }}{{$se}}">
                                                        <select class="form-control fill select-factor" name="factor_id_in">
                                                            <option value="">Select {{ $factor->factor_name }}</option>
                                                            @if($factor->range != 0)
                                                                @for($i=$factor->min_value;$i<=$factor->max_value;$i+=$factor->range)
                                                                    <option value="{{ $i }}" @if($snip->factor_value_in == $i) selected @endif > {{ $i }}</option>
                                                                @endfor
                                                            @else
                                                                @for($i=$factor->min_value;$i<=$factor->max_value;$i++)
                                                                    <option value="{{ $i }}" @if($snip->factor_value_in == $i) selected @endif > {{ $i }}</option>
                                                                @endfor
                                                            @endif

                                                        </select>
                                                        <span class="factor_id_in text-danger"></span>
                                                    </div>
                                                </div>

                                            @endif

                                            @if($function->factor_id_cm != 0)
                                                @php
                                                    $factor = App\Models\Patterns\Factor::where('id',$function->factor_id_cm)->first();
                                                @endphp

                                                <div class="col-lg-6 snippet-accordion factor_column">
                                                    <div class="row theme-row m-b-10">
                                                        <div class="card-header accordion p-1 col-lg-12 col-sm-12" data-toggle="collapse" data-target="#child-accord1factor_column1{{ $allsec->id }}{{$se}}">
                                                            <h5 class="card-header-text">{{ $factor->factor_name }}:</h5><i class="icon fa fa-caret-down pull-right micro-icons"></i> </div>
                                                    </div>
                                                    <div class="card-block collapse" id="child-accord1factor_column1{{ $allsec->id }}{{$se}}">
                                                        <select class="form-control fill select-factor" name="factor_id_cm">
                                                            <option value="">Select {{ $factor->factor_name }}</option>
                                                            @if($factor->range != 0)
                                                                @for($i=$factor->min_value;$i<=$factor->max_value;$i+=$factor->range)
                                                                    <option value="{{ $i }}" @if($snip->factor_value_cm == $i) selected @endif > {{ $i }}</option>
                                                                @endfor
                                                            @else
                                                                @for($i=$factor->min_value;$i<=$factor->max_value;$i++)
                                                                    <option value="{{ $i }}" @if($snip->factor_value_cm == $i) selected @endif > {{ $i }}</option>
                                                                @endfor
                                                            @endif

                                                        </select>
                                                        <span class="factor_id_cm text-danger"></span>
                                                    </div>
                                                </div>
                                            @endif

                                            @if($function->modifier_id != 0)
                                                @php
                                                    $modifier = App\Models\Patterns\Modifier::where('id',$function->modifier_id)->first();
                                                @endphp

                                                <div class="col-lg-6 snippet-accordion factor_column">
                                                    <div class="row theme-row m-b-10">
                                                        <div class="card-header accordion p-1 col-lg-12 col-sm-12" data-toggle="collapse" data-target="#child-accord1modifier_column1{{ $allsec->id }}{{$se}}">
                                                            <h5 class="card-header-text">{{ $modifier->modifier_name }}:</h5><i class="icon fa fa-caret-down pull-right micro-icons"></i> </div>
                                                    </div>
                                                    <div class="card-block collapse" id="child-accord1modifier_column1{{ $allsec->id }}{{$se}}">
                                                        <select class="form-control fill select-factor" name="modifier">
                                                            <option value="">Select {{ $modifier->modifier_name }}</option>

                                                            @if($modifier->is_negative == 1)
                                                                @foreach (range('-'.$modifier->max_value, $modifier->max_value) as $number) {
                                                                @if($number > 0)
                                                                    <option @if($snip->modifier_value == $number) selected @endif value="{{ $number }}">+ {{ $number }} stitches</option>
                                                                @elseif($number == 0)
                                                                    <option @if($snip->modifier_value == $number) selected @endif value="{{ $number }}">+ {{ $number }} stitches</option>
                                                                @else
                                                                    <option @if($snip->modifier_value == $number) selected @endif value="{{ $number }}"> {{ $number }} stitches</option>
                                                                @endif
                                                                @endforeach
                                                            @else
                                                                @for($j=$modifier->min_value;$j<=$modifier->max_value;$j++)
                                                                    <option @if($snip->modifier_value == $j) selected @endif value="{{ $j }}">+ {{ $j }} stitches</option>
                                                                @endfor
                                                            @endif
                                                        </select>
                                                        <span class="modifier text-danger"></span>
                                                    </div>
                                                </div>

                                            @endif


                                        </div>
                                        @if($snip->snippetConditionalStatements()->count() > 0)
                                            <div class="row m-t-20" id="cond-row">
                                                <div class="col-lg-12">
                                                    <?php $k=1; ?>
                                                    @foreach($snip->snippetConditionalStatements as $snipCond)
                                                        @php
                                                            $checkbox = DB::table('p_snippets_same_conditions')->where('snippets_id',$snip->id)->where('conditional_statements_id',$snipCond->id)->first();
                                                        @endphp
                                                        <input type="hidden"  class="cond_stmt_id{{$se}}" name="cond_stmt_id[]" data-k="{{$k}}" value="{{ $snipCond->id }}">

                                                        <div class="card-header m-b-5 snippet{{$se}}" role="tab" id="headingOne1{{$allsec->id}}{{$snipCond->id}}{{$se}}" style="background-color: #dedddd;">
                                                            <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseOne1{{$snipCond->id}}{{$k}}{{$se}}" aria-expanded="true" aria-controls="collapseOne1">
                                                                <h5 class="mb-0">
                                                                    {!! $snipCond->description !!} :- {!! $snipCond->statement_description !!}
                                                                </h5>
                                                                <i class="icon fa fa-caret-down pull-right micro-icons"></i>
                                                            </a>

                                                            <div class="row" style="position: absolute;right: 50px;z-index: 10;top: 10px;@if($k == 1) display:none; @endif" >
                                                                <div class="col-md-12">
                                                                    <div class="checkbox">

                                                                        <input type="checkbox" class="sameAsCondition sameCond1{{$se}}" id="sameCond1{{$snipCond->id}}{{$k}}{{$se}}"  value="{{$snipCond->id}}" data-tabid="{{$allsec->id}}{{$snipCond->id}}{{$se}}" data-divId="{{$snipCond->id}}{{$k}}{{$se}}" data-condid="{{$snipCond->id}}" data-sid="{{$se}}" data-k="{{$k}}" @if($checkbox->sameAsCondition == 1) checked @endif value="{{$checkbox->id}}">Same like Condition 1
                                                                        <input type="hidden" name="sameAsCondition[]" value="@if($checkbox->sameAsCondition == 1) 1 @else 0 @endif" >
                                                                        <input type="hidden" name="checkbox_id[]" value="{{$checkbox->id}}" >

                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                        <div id="collapseOne1{{$snipCond->id}}{{$k}}{{$se}}" class="collapse snippets{{$se}}{{$snipCond->id}}" role="tabpanel" aria-labelledby="headingOne1" data-parent="#accordionEx">
                                                            <ul class="list-unstyled m-b-10" style="margin-left: 10px;" id="cond_instruction">
                                                            @php
                                                                $inst = $snipCond->base_instructions;
                                                                $array = array('[[PART-1]]','[[PART-2]]','[[PART-3]]','[[PART-4]]','[[PART-5]]','[[PART-6]]','[[PART-7]]','[[PART-8]]','[[PART-9]]','[[PART-10]]','[[PART-11]]','[[PART-12]]','[[PART-13]]','[[PART-14]]');

                                                                $array1 = array('<span class="text-danger">[[PART-1]]</span>','<span class="text-danger">[[PART-2]]</span>','<span class="text-danger">[[PART-3]]</span>','<span class="text-danger">[[PART-4]]</span>','<span class="text-danger">[[PART-5]]</span>','<span class="text-danger">[[PART-6]]</span>','<span class="text-danger">[[PART-7]]</span>','<span class="text-danger">[[PART-8]]</span>','<span class="text-danger">[[PART-9]]</span>','<span class="text-danger">[[PART-10]]</span>','<span class="text-danger">[[PART-11]]</span>','<span class="text-danger">[[PART-12]]</span>','<span class="text-danger">[[PART-13]]</span>','<span class="text-danger">[[PART-14]]</span>');
                                                                $res = str_replace($array,$array1,$inst);
                                                            @endphp
                                                            <!-- <li class="desc"><b>Instruction :- </b>{!! $res !!}</li> -->
                                                            </ul>
                                                            @for($l=1;$l<=$snipCond->instructions_count;$l++)
                                                                <input type="hidden" class="conditional_statements_id{{$se}}" name="conditional_statements_id[]" value="{{ $snipCond->id }}">
                                                            @endfor

                                                            @php
                                                                $sinstructions = DB::table('p_snippet_instructions')->where('snippets_id',$snip->id)->where('conditional_statements_id',$snipCond->id)->get();
                                                            @endphp
                                                            <?php $n=1; ?>
                                                            @foreach($sinstructions as $inst)
                                                                @php $instructions = App\Models\Patterns\Instructions::where('id',$inst->instructions_id)->first(); @endphp
                                                                <input type="hidden" name="instructions_id[]" value="{{ $instructions->id }}">
                                                            <!-- <h5 class="m-t-10 text-danger">PART-{{ $n }}</h5> -->
                                                                <h5 class="m-t-10 text-danger">Instruction</h5>
                                                                <textarea class="hint2mention summernote m-b-10" id="editor{{$snipCond->id}}{{$k}}{{$se}}{{$n}}" name="description[]" data-condid="{{$snipCond->id}}" data-cid="{{$allsec->id}}{{$snipCond->id}}" data-sid="{{$se}}" data-k="{{$k}}" data-l="{{$n}}">{!! $instructions->description !!}</textarea>
                                                                <span class="summernote-required text-danger"></span>
                                                                @component('designer.patterns.summernote', ['condId' => $snipCond->id,'k' => $k,'dataCount' => $se,'l' => $n,'outputVariables' => $function->outputVariables,'measurements' => $measurements]) @endcomponent
                                                                <?php $n++; ?>
                                                            @endforeach
                                                            <br>
                                                        </div>
                                                        <?php $k++; ?>
                                                    @endforeach



                                                </div>
                                            </div>
                                        @endif


                                        <div class="col-lg-12">
                                            <button type="button" class="btn theme-btn btn-sm pull-right m-t-10 updateSnippet" data-snippet-id="{{ $se }}" data-id="sectionForm{{$allsec->id}}{{$se}}">Save</button>
                                        </div>
                                        <!-- formulas end here -->
                                    </div>


                            @endif <!-- function id != 0 condition -->

                            </div>

                        </form>

                    </div>
                    <?php $se++; ?>
                @endforeach

            @endif
            <div class="row">
                <div class="col-md-12" id="addSnippet{{$allsec->id}}"></div>
            </div>

            <div class="row">
                <div class="col-lg-12 text-center">
                    <button type="button" class="btn theme-btn m-b-20 btn-sm add-snippet"  onclick="addSnippet({{$allsec->id}})" data-id="{{$allsec->id}}"><i class="fa fa-plus"></i>Add snippet</button>
                </div>
            </div>
        </div>

        </div>
        @php $sec++; @endphp
    @endforeach

@endif


